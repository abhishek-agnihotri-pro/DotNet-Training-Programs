
// namespace MVC_EDUHUB.ViewModel
// {
//     public class SelectListItem
//     {
//         public string? Text { get; set; }
//         public string? Value { get; set; }
//     }
// }