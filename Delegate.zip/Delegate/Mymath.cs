class Mymath
{
    public static void Add(int a, int b){
        Console.WriteLine($"{a} + {b} = {a+b}");
    }
    public static void Sub(int a, int b){
        Console.WriteLine($"{a} - {b} = {a-b}");
    }
    public static void Multiply(int a, int b){
        Console.WriteLine($"{a} x {b} = {a*b}");
    }
    public static void Divivde(int a, int b){
        Console.WriteLine($"{a} / {b} = {a/b}");
    }
}