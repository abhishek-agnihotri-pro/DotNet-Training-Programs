class ShowGreeting
{
    public static void GoodMorning(string name){
        Console.Write($"Good Morning, {name}");
    }
    public static void GoodAfterNoon(string name){
        Console.Write($"Good AfterNoon, {name}");
    }
    public static void GoodEvening(string name){
        Console.Write($"Good Evening, {name}");
    }
    public static void GoodNight(string name){
        Console.Write($"Good Night, {name}");
    }
}