using System.Security.Cryptography;

class ShowMessage
{
    public static void ShowGoodmsg(){
        Console.WriteLine("Yes ! You are Pass");
    }
    public static void ShowBadmsg(){
        Console.WriteLine("Unfortunetly, We considered to move with other applicants");
    }
}